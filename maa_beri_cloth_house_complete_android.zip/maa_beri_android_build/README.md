# Maa Beri Cloth House — Complete Clothing Shop App

Offline-first Android app project for a readymade clothing shop.

## Features
- 4–6 digit PIN lock
- Customer records and customer-wise Udhar/Jama ledger
- Itemized bills, discounts, paid amount and balance due
- Clothing catalogue with category, SKU, size, colour, purchase cost, selling price and stock quantity
- Stock is reduced automatically when a catalogue product is sold on a bill
- Low-stock indication and manual stock adjustments
- Supplier directory and stock purchase entry
- Sales, khata and estimated gross-profit summaries
- CSV transaction export
- Manual JSON backup and restore
- No GST fields; amounts use Indian rupees
- All app screens and logic are bundled locally; no internet is required for normal shop use

## Build an APK from an Android phone
1. Create a GitHub repository named `maa-beri-cloth-house`.
2. Upload the contents of this folder to the repository root, including the hidden `.github` folder.
3. Open **Actions** → **Build Maa Beri Cloth House APK** → **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed run and download the `Maa-Beri-Cloth-House-APK` artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

This workflow creates a **debug/testing APK**, not a Play Store-signed release. A signed release build and Play Console setup are separate steps.

## Data safety
Shop data stays in app storage on the phone. Use **Backup & Settings → Download Backup** regularly and keep the JSON file somewhere separate. Do not upload real customer data or backup files to GitHub. Clearing app storage or uninstalling may erase local records.
